#!/bin/sh
#sudo -i
cp -rf transparent_service.c wifi_prov_service.c ../../../buildroot-at91/output/build/bluez5_utils-5.48/tools/.
cd ../../../buildroot-at91/output/build/bluez5_utils-5.48
python ../../../../buildroot_external/package/apps/make_modify.py
make
cp -rf tools/transparent_service ../../target/usr/sbin/.
cp -rf tools/wifi_prov_service ../../target/usr/sbin/.
cp -rf tools/btgatt-server ../../target/usr/sbin/.
cd ../../..
make
